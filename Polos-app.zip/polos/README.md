# Polos – diseñador de polos (Android)

App Android con editor plano (frente/espalda) + vista 3D del polo.
Sube a GitHub: Actions compila `Polos.apk` (pestaña Actions → artefacto, o en Releases).
